from setuptools import setup

setup (
    name='searchy_wordy',
    version='1.0',
    description='Simple find letter function for testing modules',
    author='me',
    author_email='jasonr.jones14@gmail.com',
    url='something.com',
    py_modules=['searchy_wordy']
)
