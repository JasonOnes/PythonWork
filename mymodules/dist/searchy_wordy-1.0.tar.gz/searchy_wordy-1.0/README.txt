

Just a simple trial to create a module of my own for importing tests.
I hope no one is looking at this, an eight year old probably would have less
problems with it. Oh, well.
